library(testthat)
library(bacen)

test_check("bacen")
